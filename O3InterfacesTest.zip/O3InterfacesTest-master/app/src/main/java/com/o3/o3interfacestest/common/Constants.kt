package com.o3.o3interfacestest.common

object Constants {
    const val BASE_URL = "https://api.agify.io/"
}
package com.o3.o3interfacestest.domain.model

data class UserResponse (
    var userName:String="micheal",
    var count:Int=0
)

package com.o3.o3interfacestest.data.source.model

data class UserResponseDto (
    var userName:String="micheal",
    var count:Int=0)

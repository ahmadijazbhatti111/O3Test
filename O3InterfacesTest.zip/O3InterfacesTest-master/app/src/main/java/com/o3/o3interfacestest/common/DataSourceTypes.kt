package com.o3.o3interfacestest.common

enum class DataSourceTypes {
    FROM_NETWORK,
    FROM_LOCALDB
}